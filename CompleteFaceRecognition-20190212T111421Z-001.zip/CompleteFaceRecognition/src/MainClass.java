import java.util.Scanner;

public class MainClass {
	
    	
	//training folder ka path
	public final static String trainpath = "D:/eclipseProjects/YALE-Face-DB/YALE-Face-DB/YALE-Face-DB/";
	
	//testing folder ka path	
	public final static String testpath = "D:/eclipseProjects/YALE-Face-DB/YALE-Face-DB/YALE-Face-DB - Test/";
	

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter CNIC: ");
		String Targ = sc.nextLine();
		
		//for trianing un-comment neechy ki do lines
		//NearestNeighbor nn =new NearestNeighbor();
		//nn.train(trainpath,Targ);
		

		//for testing un-comment neechy ki teen lines
		//Threshold th = new Threshold();
		//th.initialize();
		//th.test(trainpath,testpath,Targ);
		
		
		// TODO Auto-generated method stub
		//TestingClass ts = new TestingClass();
		//ts.initialize();
		//ts.test(testpath);

	}

}
