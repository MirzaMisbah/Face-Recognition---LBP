import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;


public class Threshold {
	
	
	 //public static String BASE_DIR = new File(MainClass.path, "Yale_Test").getAbsolutePath();
	public String BASE_DIR = null;
	public String CLASSIFIER_FILE =null;
	public String Targeted_Folder = null;
	public String Targeted_File = null;
	    //public static final String CLASSIFIER_FILE = new File(Database.BASE_DIR, "samples.dat").getAbsolutePath();
	    //public static final String ID_FILE = new File(Database.BASE_DIR,"id.dat").getAbsolutePath();
	
	NearestNeighbor nn;

    int nFeatures;

    File trainSet;
    File trainId;
    File Tar_File;

    LinkedList<Double> topDist;
    LinkedList<String> topLabel;

    FileInputStream fis = null;
    BufferedInputStream bis = null;
    FileReader fr = null;

    DataInputStream filein;
    

    BufferedReader IDin;
    LinkedList<Double> cur;
    private int consulteds = 0;
    int s=0;

    String curId;

    
    public void initialize() {
        Locale.setDefault(Locale.US);//to read the double from text file
        cur = new LinkedList<Double>();

        //trainSet = new File(CLASSIFIER_FILE);
        //trainId = new File(ID_FILE);

        topDist = new LinkedList<Double>();
        topLabel = new LinkedList<String>();

    }
    
    public void test(String path,String Tpath,String Targ){
    	
    	BASE_DIR=path+Targ;
    	
    	//trainSet = new File(CLASSIFIER_FILE);
        //trainId = new File(ID_FILE);
        //trainWese = new File(WESE_FILE);
        int i = 0;

        String IMG =null;
        String targ = null;
        Database db = new Database(BASE_DIR);
        System.out.println("NN Listing people ...");
        //List<File> people = Database.listPeople(); // new Database()
        //Collections.sort(people);
        //for(int a=1;a<16;a++){
        	//for(int c=10;c<12;c++){
        		
        		IMG = MainClass.testpath;
        		IMG = IMG + Targ + "/1.jpg";
        		BufferedImage b = null;
				try {
					b = FaceImage.loadImage(new File(IMG));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                int width = b.getWidth();
                System.out.println("Width "+width);
                
                nn = new NearestNeighbor();
                Collection<Double> desc =nn.getDescriptor(b);
                double[] th = new double[4];
                int w=0;
                double minValue = 0;
                double Q=0;
                //List<File> people = Database.listPeople();
                //for (File person : people){
                	
                	targ = Targ;
                	int j=0;
                	
                	CLASSIFIER_FILE = new File(MainClass.trainpath+targ,targ).getAbsolutePath();
                	trainSet = new File(CLASSIFIER_FILE,targ+".dat").getAbsoluteFile();
                	//System.out.println(trainSet);
                	
                	getNumFeatures();
                    while(getSample()){
                    	
                    	if(j<th.length){
                    		
                    		th[j] = distance(desc,cur);
                    	}
                    	j++;	
                   }
                    double sum = 0;
                    double std = 0;
                    for (int z=0;z<th.length;z++){

                        sum += th[z];
                    }
                    
                    double mean = sum/th.length;
                    System.out.println("Test Mean with "+targ+" "+mean);
                    /*for(int v=0;v<th.length;v++){
                    	
                    	std += (th[v]-mean)*(th[v]-mean);
                    }
                    
                    double sd = Math.sqrt(std/(th.length-1));
                    Q = mean+sd;
                    System.out.println("Threshold "+person.getName()+" "+(mean+sd));*/
                    
                    if(w==0){
                    	
                    	minValue = mean;
                    	w++;
                    	Targeted_Folder = CLASSIFIER_FILE;
                    	Targeted_File = targ;
                    }
                    else{
                    	
                    	if(minValue > mean){
                    		
                    		minValue = mean;
                    		Targeted_Folder = CLASSIFIER_FILE;
                    		Targeted_File = targ;
                    	}
                    }
                    
               //}
               double tard = 0;
              
               System.out.println(Targeted_Folder);
               System.out.println(Targeted_File);
               trainSet = new File(Targeted_Folder,Targeted_File+".txt").getAbsoluteFile();
               getNumFeatures();
               try {
            	   tard = filein.readFloat();
            	   System.out.println("train treshold "+tard);
            	   
               } catch (IOException e) {
				// TODO Auto-generated catch block
            	   e.printStackTrace();
               }
               if((minValue) < tard){
            	   
            	   System.out.println("Person "+ Targeted_File+" Matched :*");
               }
               else
               {
            	   System.out.println("Not Matched :P");
               }
               /*for(int k =0;k<th.length;k++){
             	   
             	   System.out.println("Chi square "+th[k]);
               }*/
        	}
     //   }
   // }
	private boolean getSample(){

        cur.clear();
        //String s;
        
        try{
        	s++;
        	if(s>9){
        		s=0;
        		return false;
        	}
            //s = IDin.readLine();
            //if (s==null) {
              //  return false;
            //}
            //curId = s;
            for (int i = 0; i < nFeatures; i++) {
                double d = filein.readFloat();
                cur.addLast(d);
            }
        }
        catch(Exception e){}

        return true;
    }
	
	private void getNumFeatures(){

        try {
            //Log.v("NN", "File stream closing ...");
            if(filein!=null){
                filein.close();
                //IDin.close();
                filein = null;
                //IDin = null;
            }
            //Log.v("NN", String.format("File stream opening ...%s %s", trainSet.getName(), trainId.getName()));

            if(fis!=null){
                fis.close();
                fis=null;
            }
            if(bis!=null){
                bis.close();
                bis=null;
            }
            if(fr!=null){
                fr.close();
                fr=null;
            }

            System.gc();

            fis = new FileInputStream(trainSet);
            bis = new BufferedInputStream(fis,2*1024);
            filein = new DataInputStream(bis);//buffer-100k

            //fr = new FileReader(trainId);
            //IDin = new BufferedReader(fr, 2*1024);
            //System.out.println("NN File stream opened");

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        int x = 0;
        try {
            x = filein.readInt();
            
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        nFeatures = x;
        //Log.v("Info", "Features Number Loaded: "+nFeatures);
    }
	
	
	private double chiSquareDistance(Collection<Double> i1, Collection<Double> i2){

        double dist = 0.0;
        double diff;
        double v1, v2;
        double sum;
        
        assert(i1.size()==i2.size()):"Nao tem o mesmo numero de caracteristicas";

        Iterator<Double> it1 = i1.iterator();
        Iterator<Double> it2 = i2.iterator();

        //Log.v("Info", String.format("Features Number - distance function: %d %d", i1.size(), i2.size()));

        int nFeatures = i1.size();
        for (int i = 0; i < nFeatures; i++)
        {
            v1 = it1.next();
            v2 = it2.next();

            diff = v1 - v2;
            sum = v1 + v2;

            //Log.v("Chi Square", String.format("%f, %f", v1, v2));

            if(sum>0.0)
                dist += (diff*diff)/sum;
        }//while

        return 0.5*dist;
    }

    public double distance(Collection<Double> c1, Collection<Double> c2) {
        // TODO Auto-generated method stub
        return chiSquareDistance(c1, c2);
    }

}
