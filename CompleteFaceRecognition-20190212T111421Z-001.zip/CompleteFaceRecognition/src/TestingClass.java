import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;


public class TestingClass {
	
	
	 //public static String BASE_DIR = new File(MainClass.path, "Yale_Test").getAbsolutePath();
	public String BASE_DIR = null;
	public String CLASSIFIER_FILE =null;
	    //public static final String CLASSIFIER_FILE = new File(Database.BASE_DIR, "samples.dat").getAbsolutePath();
	    //public static final String ID_FILE = new File(Database.BASE_DIR,"id.dat").getAbsolutePath();
	
	NearestNeighbor nn;

    int nFeatures;

    File trainSet;
    File trainId;

    LinkedList<Double> topDist;
    LinkedList<String> topLabel;

    FileInputStream fis = null;
    BufferedInputStream bis = null;
    FileReader fr = null;

    DataInputStream filein;
    

    BufferedReader IDin;
    LinkedList<Double> cur;
    private int consulteds = 0;
    int s=0;

    String curId;
    
    public void initialize() {
        Locale.setDefault(Locale.US);//to read the double from text file
        cur = new LinkedList<Double>();

        //trainSet = new File(CLASSIFIER_FILE);
        //trainId = new File(ID_FILE);

        topDist = new LinkedList<Double>();
        topLabel = new LinkedList<String>();

    }
    
    public void test(String path){
    	
    	BASE_DIR=path;
    	
    	//trainSet = new File(CLASSIFIER_FILE);
        //trainId = new File(ID_FILE);
        //trainWese = new File(WESE_FILE);
        int i = 0;

        double count = 0;
        int uv = 8;
        int lv = 0;
        String IMG =null;
        Database db = new Database(BASE_DIR);
        System.out.println("NN Listing people ...");
        //List<File> people = Database.listPeople(); // new Database()
        //Collections.sort(people);
        for(int a=1;a<16;a++){
        	for(int c=10;c<12;c++){
        		
        		IMG = "C:/Users/Sadam Hussain/Desktop/AndroidEye/Yale_Test/s" + a + "/" + c + ".gif";
        		BufferedImage b = null;
				try {
					b = FaceImage.loadImage(new File(IMG));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                int width = b.getWidth();
                //Log.d("Da","Width "+width);
                System.out.println("Width "+width);
                //ui.callSpeaker("Width: "+b.getWidth()+", Height: "+b.getHeight());
                //b = FaceImage.resizeBitmap(b, 0.5, 0.5);
                //String s = person.getName();//directory name is the person ID
                
                int dat=1;
                nn = new NearestNeighbor();
                Collection<Double> desc =nn.getDescriptor(b);
                double[] th = new double[135];
                int j=0;
                while(dat<16){
                	
                	CLASSIFIER_FILE = new File(MainClass.trainpath,"s"+dat).getAbsolutePath();
                	trainSet = new File(CLASSIFIER_FILE,"s"+dat+".dat").getAbsoluteFile();
                	//System.out.println(trainSet);
                	
                	getNumFeatures();
                    dat++;
                    while(getSample()){
                    	
                    	if(j<th.length){
                    		
                    		th[j] = distance(desc,cur);
                    	}
                    	j++;	
                   }
                }
                for(int k =0;k<th.length;k++){
             	   
             	   System.out.println("Chi square "+th[k]);
                }
                double minValue = th[0];
                int index =0;
                for(int p=1;p<th.length;p++){  
                	if(th[p] < minValue){
                	
                		minValue = th[p];
                		index = p;
                		
                	}  
                }
                System.out.println("Index "+index);
                if(index <= uv && index >= lv){
             	   count = count+1;
             	   
                }
                
                //System.out.println("Adding " +Database.personName(person.getName()));
                //b = FaceImage.cropFace(b, r.get(0));
               
            }
            uv = uv+9;
            lv = lv+9;
        	}
        System.out.println("Count "+(count/(15*2))*100);
        System.out.println("The algorithm efficency: "+(count/(15*2))*100);
        }
        //for(File s:people){
        	//System.out.println(s);
        //}
        //File dirlist= new File(BASE_DIR);
       /* System.out.println("NN People number: "+people.size());
        for (File person : people) {
        	
            System.out.println("NN Adding " + person.getName());
            
            List<File> imgs = Database.listImages(person);
            for (File file : imgs) {
                System.out.println("NN Opening image "+file.getName());

                BufferedImage b = null;
				try {
					b = FaceImage.loadImage(new File(IMG));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                int width = b.getWidth();
                //Log.d("Da","Width "+width);
                System.out.println("Width "+width);
                //ui.callSpeaker("Width: "+b.getWidth()+", Height: "+b.getHeight());
                //b = FaceImage.resizeBitmap(b, 0.5, 0.5);
                String s = person.getName();//directory name is the person ID
                
                int dat=1;
                nn = new NearestNeighbor();
                Collection<Double> desc =nn.getDescriptor(b);
                double[] th = new double[135];
                int j=0;
                while(dat<16){
                	
                	CLASSIFIER_FILE = new File(MainClass.trainpath,""+dat).getAbsolutePath();
                	trainSet = new File(CLASSIFIER_FILE,""+dat+".dat").getAbsoluteFile();
                	//System.out.println(trainSet);
                	
                	getNumFeatures();
                    dat++;
                    while(getSample()){
                    	
                    	if(j<th.length){
                    		
                    		th[j] = distance(desc,cur);
                    	}
                    	j++;	
                   }
                }
                for(int k =0;k<th.length;k++){
             	   
             	   //System.out.println("Chi square "+th[k]);
                }
                double minValue = th[0];
                int index =0;
                for(int p=1;p<th.length;p++){  
                	if(th[p] < minValue){
                	
                		minValue = th[p];
                		index = p;
                		
                	}  
                }
                System.out.println("Index "+index);
                if(index <= uv && index >= lv){
             	   count = count+1;
             	   
                }
                
                //System.out.println("Adding " +Database.personName(person.getName()));
                //b = FaceImage.cropFace(b, r.get(0));
               
            }
            uv = uv+9;
            lv = lv+9;
        }
        System.out.println("Count "+count);*/
    
   /* public static double getMinValue(double[] array){  
        double minValue = array[0];
        int index;
        for(int i=1;i<array.length;i++){  
        	if(array[i] < minValue){
        	
        		minValue = array[i];
        		index = i;
        		
        	}  
        }  
        return minValue;  
   } */
	
	
	private boolean getSample(){

        cur.clear();
        //String s;
        
        try{
        	s++;
        	if(s>9){
        		s=0;
        		return false;
        	}
            //s = IDin.readLine();
            //if (s==null) {
              //  return false;
            //}
            //curId = s;
            for (int i = 0; i < nFeatures; i++) {
                double d = (double)filein.readFloat();
                cur.addLast(d);
            }
        }
        catch(Exception e){}

        return true;
    }
	
	private void getNumFeatures(){

        try {
            //Log.v("NN", "File stream closing ...");
            if(filein!=null){
                filein.close();
                //IDin.close();
                filein = null;
                //IDin = null;
            }
            //Log.v("NN", String.format("File stream opening ...%s %s", trainSet.getName(), trainId.getName()));

            if(fis!=null){
                fis.close();
                fis=null;
            }
            if(bis!=null){
                bis.close();
                bis=null;
            }
            if(fr!=null){
                fr.close();
                fr=null;
            }

            System.gc();

            fis = new FileInputStream(trainSet);
            bis = new BufferedInputStream(fis,2*1024);
            filein = new DataInputStream(bis);//buffer-100k

            //fr = new FileReader(trainId);
            //IDin = new BufferedReader(fr, 2*1024);
            //System.out.println("NN File stream opened");

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        int x = 0;
        try {
            x = filein.readInt();
            
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        nFeatures = x;
        //Log.v("Info", "Features Number Loaded: "+nFeatures);
    }
	
	
	private double chiSquareDistance(Collection<Double> i1, Collection<Double> i2){

        double dist = 0.0;
        double diff;
        double v1, v2;
        double sum;
        
        assert(i1.size()==i2.size()):"Nao tem o mesmo numero de caracteristicas";

        Iterator<Double> it1 = i1.iterator();
        Iterator<Double> it2 = i2.iterator();

        //Log.v("Info", String.format("Features Number - distance function: %d %d", i1.size(), i2.size()));

        int nFeatures = i1.size();
        for (int i = 0; i < nFeatures; i++)
        {
            v1 = it1.next();
            v2 = it2.next();

            diff = v1 - v2;
            sum = v1 + v2;

            //Log.v("Chi Square", String.format("%f, %f", v1, v2));

            if(sum>0.0)
                dist += (diff*diff)/sum;
        }//while

        return 0.5*dist;
    }

    public double distance(Collection<Double> c1, Collection<Double> c2) {
        // TODO Auto-generated method stub
        return chiSquareDistance(c1, c2);
    }

}
