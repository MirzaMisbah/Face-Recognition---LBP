import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
public class FaceImage {
	
	private static final int IMG_WIDTH = 82;
	private static final int IMG_HEIGHT = 82;

    /*public static BufferedImage loadImage(String filename)
    {
    	

    	ImageIO.R
        Bitmap b = BitmapFactory.decodeFile(filename);
        return b;
    }*/

    public static BufferedImage loadImage(File f) throws IOException
    {
    	return ImageIO.read(f);
        //return loadImage(f.getAbsolutePath());
    }
    
    public static BufferedImage resizeImage(BufferedImage originalImage, int type){
    	BufferedImage resizedImage = new BufferedImage(IMG_WIDTH, IMG_HEIGHT, type);
    	Graphics2D g = resizedImage.createGraphics();
    	g.drawImage(originalImage, 0, 0, IMG_WIDTH, IMG_HEIGHT, null);
    	g.dispose();
    		
    	return resizedImage;
        }

   /* public static Bitmap resizeBitmap(Bitmap bm, double scale) {
        return resizeBitmap(bm, scale, scale);
    }

    public static Bitmap resizeBitmap(Bitmap bm, double scaleWidth, double scaleHeight) {
        int width = bm.getWidth();
        int height = bm.getHeight();

        // create a matrix for the manipulation
        Matrix matrix = new Matrix();

        // resize the bit map
        matrix.postScale((float)scaleWidth, (float)scaleHeight);

        Log.v("Scale", "Matrix ready");
        // recreate the new Bitmap
        Bitmap resizedBitmap = Bitmap.createBitmap(bm, 0, 0, width, height, matrix, true);

        Log.v("Scale", "Bitmap resized");

        return resizedBitmap;
    }*/
}
