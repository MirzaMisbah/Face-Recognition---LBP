


import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.util.Collection;
import java.util.LinkedList;

public class MeraLbp {

    double feats[]= new double[256];
    int pixels[];
    

    private int gray(int color)
    {
    	
    	Color mycol = new Color(color);
        //return (int) ((0.2126* Color.red(color)+0.7152*Color.green(color)+0.0722*Color.blue(color))%256);
    	return (int) ((0.2126* mycol.getRed()+0.7152*mycol.getGreen()+0.0722*mycol.getBlue())%256);
    }

    private int getPixel(int pixels[], int x, int y, int width)
    {
        return pixels[y*width+x];
    }

    public Collection<Double> lbpa(BufferedImage img){

        for(int i=0; i<feats.length; ++i)
            feats[i] = 0.0;

        if(pixels==null || pixels.length<(img.getHeight()*img.getWidth()))
        {
            pixels = new int[img.getWidth()*img.getHeight()];
        }

        int width = img.getWidth();
        int height = img.getHeight();

        
        long t = System.currentTimeMillis();
        //img.getPixels(pixels, 0, width, 0, 0, width, height);
        img.getRGB(0, 0, width, height, pixels, 0,width);
        t = System.currentTimeMillis() - t;

        //System.out.println("getdata " + (double) (t) / 1000.0);

        /*for (int i = 0; i < pixels.length; i++) {

        	//System.out.println("Before Gray"+pixels[i]);
            pixels[i] = gray(pixels[i]);
            //System.out.println("After Gray"+pixels[i]);
        }*/

        // 3x3 ka slider chal raha hai...
        for(int i=1; i<width-1; ++i)
        {
            for (int j = 1; j < height-1 ; ++j) {

                int output = 0;
                int cur = getPixel(pixels, i, j, width);

                if (getPixel(pixels, i-1, j-1, width)>=cur) {
                    output = 1;
                }
                else
                {
                    output = 0;
                }

                if (getPixel(pixels, i, j-1, width)>=cur) {
                    output = (output << 1) + 1;
                }
                else
                {
                    output = (output << 1) + 0;
                }

                if (getPixel(pixels, i+1, j-1, width)>=cur) {
                    output = (output << 1) + 1;
                }
                else
                {
                    output = (output << 1) + 0;
                }

                if (getPixel(pixels, i+1, j, width)>=cur) {
                    output = (output << 1) + 1;
                }
                else
                {
                    output = (output << 1) + 0;
                }

                if (getPixel(pixels, i+1, j+1, width)>=cur) {
                    output = (output << 1) + 1;
                }
                else
                {
                    output = (output << 1) + 0;
                }

                if (getPixel(pixels, i, j+1, width)>=cur) {
                    output = (output << 1) + 1;
                }
                else
                {
                    output = (output << 1) + 0;
                }

                if (getPixel(pixels, i-1, j+1, width)>=cur) {
                    output = (output << 1) + 1;
                }
                else
                {
                    output = (output << 1) + 0;
                }

                if (getPixel(pixels, i-1, j, width)>=cur) {
                    output = (output << 1) + 1;
                }
                else
                {
                    output = (output << 1) + 0;
                }
                //System.out.println("Before "+pixels[j*width+i]);
                //Log.d("Before","Before "+pixels[j*width+i]);
                pixels[j*width+i]=output;
                //System.out.println("Output "+output);
                //System.out.println("Index Number "+(j*width+1));
                //System.out.println("After Lbp "+pixels[j*width+1]);
            }
        }
        BufferedImage lbpimg = new BufferedImage(80,80,BufferedImage.TYPE_BYTE_BINARY);
		WritableRaster raster = lbpimg.getRaster();
		
		for(int m = 0; m < 80; m ++ ){
			for(int n = 0; n < 80; n ++){
				int value = pixels[n];
				//System.out.println("Value "+value);
				raster.setSample(n,m,0,value);
				
			}
		}
		//imbosed image
/*		File file = new File("C:/Users/mubee/workspace/YALE-Face-DB/YALE-Face-DB - abc"+1+".png");
		try {
			file.createNewFile();
			
			ImageIO.write(lbpimg,"png",file);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
*/
        LinkedList<Double> features = new LinkedList<Double>();
        int IniW = 1;
        int IniH = 1;
        int wframe = 8;
        int hframe = 8;
        // 8x8 ka slider chal raha hai for histogram...

        for (int i = 0; i+wframe < img.getWidth();) {

            for (int j = 0; j + hframe < img.getHeight();) {

                for (int k = IniW; k <= wframe; k++) {
                    for (int l = IniH; l <= hframe; l++) {

                        //Log.d("Index", "Pixel " + (l * width + k));
                        int c = pixels[l * width + k];
                        //Log.d("Pixel", "Value " + c);
                        feats[c]++;
                        //Log.d("Feats", "Output++ " + feats[c]);
                    }
                }
                hframe+=8;
                IniH+=8;

                LinkedList<Double> list = new LinkedList<Double>();

                for (int f = 0; f < feats.length; f++) {
                    list.addLast(feats[f]);
                }
                for(int p=0; p<feats.length; ++p)
                    feats[p] = 0.0;
                Iterable<Double> it = list;
                for (Double double1 : it) {
                    features.addLast(double1);
                }
            }
            IniW+=8;
            wframe+=8;
            IniH=1;
            hframe=8;
        }
        /*LinkedList<Double> list = new LinkedList<Double>();

        for (int i = 0; i < feats.length; i++) {
            list.addLast(feats[i]);
        }
        return list;*/
        return features;
    }
}
