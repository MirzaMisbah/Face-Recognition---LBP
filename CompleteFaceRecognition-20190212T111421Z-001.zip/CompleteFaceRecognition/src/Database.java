
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
public class Database {

	
	//public static String BASE_DIR = new File(MainClass.path, "YALE-Face-DB").getAbsolutePath();
	public static String BASE_DIR=null;
	
	public Database(String path)
	{
		this.BASE_DIR = path;
	}


    public static List<File> listPeople()
    {
        File dirlist= new File(BASE_DIR);
        System.out.println("Database "+ dirlist.getName());
        File l[]=dirlist.listFiles();
        LinkedList<File> people = new LinkedList<File>();
        System.out.println("Folder "+l.length);

        for (File file : l) {
            if(file.isDirectory()){
                people.addLast(file);
            }
        }
        return people;
    }

    public static List<File> listImages(File personDir)
    {
        LinkedList<File> img = new LinkedList<File>();
        File l2[]=personDir.listFiles();
        for (File file2 : l2) {

            if(file2.getName().endsWith(".jpg") ){
                img.addLast(file2);
            }
        }
        return img;
    }

    //1st come here
    public static String personName(String personId){
        File dir = new File(BASE_DIR, personId);
        return personName(dir);
    }

    //then here
    public static String personName(File personDir){
        String s = null;
        File f = new File(personDir, "name.txt");
        try {
            BufferedReader br = new BufferedReader(new FileReader(f));
            s = br.readLine();
            br.close();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            s = null;
        }

        return s;
    }
    
    
}
