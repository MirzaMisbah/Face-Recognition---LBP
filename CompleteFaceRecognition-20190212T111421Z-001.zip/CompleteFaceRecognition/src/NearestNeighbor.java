
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.List;

import javax.imageio.ImageIO;

public class NearestNeighbor {


    public String BASE_DIR = null;
    //public static String TBASE_DIR = new File(MainClass.path, "Yale_Test").getAbsolutePath();
    
    //public static final String CLASSIFIER_FILE = new File(Database.BASE_DIR, "samples.dat").getAbsolutePath();
    //public static final String ID_FILE = new File(Database.BASE_DIR,"id.dat").getAbsolutePath();
    //public static final String WESE_FILE = new File(Database.BASE_DIR,"wese.txt").getAbsolutePath();

    //FaceDescriptor descriptor;
    MeraLbp mlbp;
    int nFeatures;

    //Collection<Double> desc;
    File trainSet;
    File trainId;
    File trainWese;


    //int count=0;
    public static final int WIDTH = 82;

    double feats[]= new double[256];
    int pixels[];

    FileInputStream fis = null;
    BufferedInputStream bis = null;
    FileReader fr = null;

    DataOutputStream fileout;
    DataInputStream filein;
    DataInputStream wesein;

    DataOutputStream weseout;
    BufferedWriter IDout;
    
    BufferedReader IDin;
    Threshold tc;
    
    Collection<Double> desc1;
    Collection<Double> desc2;
    Collection<Double> desc3;
    Collection<Double> desc4;
    double[] th = new double[6];
    

    public void train(String trainfol,String Targ){

    	BASE_DIR = trainfol + Targ;
        //trainSet.delete();//if exists, doesn't exist anymore
        //trainId.delete();

        /*try {
            trainSet.createNewFile();
            trainId.createNewFile();
        } catch (IOException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }*/

        //trainSet = new File(CLASSIFIER_FILE);
        //trainId = new File(ID_FILE);
        //trainWese = new File(WESE_FILE);
        

    	Database db = new Database(BASE_DIR);
        System.out.println("NN Listing people ...");
        List<File> people = Database.listPeople();
        //File dirlist= new File(BASE_DIR);
        System.out.println("NN People number: "+people.size());
        for (File person : people) {
        	int i = 0;
        	int y =0;
            System.out.println("NN Adding " + person.getName());
            String dara = new File(BASE_DIR,person.getName()).getAbsolutePath();
            trainSet = new File(dara,person.getName()+".dat");
            trainWese = new File(dara,person.getName()+".txt");
            List<File> imgs = Database.listImages(person);
            	for (File file : imgs) {
                    //System.out.println("NN Opening image "+file.getName());

                    BufferedImage b = null;
    				try {
    					b = FaceImage.loadImage(file);
    				} catch (IOException e) {
    					// TODO Auto-generated catch block
    					e.printStackTrace();
    				}
                    //int width = b.getWidth();
                    //Log.d("Da","Width "+width);
                    //System.out.println("Width "+width);
                    //ui.callSpeaker("Width: "+b.getWidth()+", Height: "+b.getHeight());
                    //b = FaceImage.resizeBitmap(b, 0.5, 0.5);
                    String s = person.getName();//directory name is the person ID


                    //System.out.println("Adding " +Database.personName(person.getName()));
                    //b = FaceImage.cropFace(b, r.get(0));
                    Collection<Double> desc =getDescriptor(b);
                    
                    if(y==0)
                    {
                    	desc1 = getDescriptor(b);
                    }
                    else if(y==1)
                    {
                    	desc2 = getDescriptor(b);
                    }
                    else if(y==2)
                    {
                    	desc3 = getDescriptor(b);
                    }
                    else if(y==3)
                    {
                    	desc4 = getDescriptor(b);
                    }

                    //System.out.println("Desc"+"Size "+desc.size());
                    
                    if(i==0){
                        setNumFeatures(desc.size());
                    }
                    if(desc!=null){
                    	
                    	
                        addSample(s, desc);
                        //ui.callSpeaker(String.format("%s added to classifier.", file.getName()));
                        //Log.v("NN", String.format("%s added to classifier.", file.getName()));
                        //System.out.println("added to classifier "+file.getName());
                        i++;
                        y++;
                    }
                    
                    
                    
                    
                }
            	
            	
            	tc = new Threshold();
            	//double dd = tc.distance(desc1, desc2);
            	
            	th[0] = tc.distance(desc1,desc2);
                th[1] = tc.distance(desc1,desc3);
                th[2] = tc.distance(desc1,desc4);
                th[3] = tc.distance(desc2,desc3);
                th[4] = tc.distance(desc2,desc4);
                th[5] = tc.distance(desc3,desc4);
            	
                for(int w =0;w<th.length;w++){
            	
                	System.out.println("Chi square "+th[w]);
                }
                double sum = 0;
                double std = 0;
                for (int z=0;z<th.length;z++){

                    sum += th[z];
                }
                
                double mean = sum/th.length;
                System.out.println("Mean "+mean);
                for(int v=0;v<th.length;v++){
                	
                	std += (th[v]-mean)*(th[v]-mean);
                }
                
                double sd = Math.sqrt(std/(th.length-1));
                double Q = mean+sd;
                System.out.println("Threshold "+(mean+sd));
            	
            	try {
            		
            		weseout.writeFloat((float)Q);
            		weseout.flush();
					fileout.flush();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            	
            }
        try {
        	
            fileout.close();
            weseout.close();
            //IDout.close();
            //filein = new DataInputStream(new FileInputStream(trainSet));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private void addSample(String s, Collection<Double> c)
    {
        try{
            int count =0;
            //IDout.write(s + '\n');
            //Assert.assertTrue(c.size() == nFeatures);
            for (double d: c) {
                count++;
                //Log.d("Counter","Number"+count);
                //Log.d("Yeh","Sample "+(int)d);
                fileout.writeFloat((float)d);
                //weseout.write(""+d + '\n');
                //fileout.write((int)d);
            }
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
    private void setNumFeatures(int numFeatures){
        nFeatures=numFeatures;
        try {
            fileout = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(trainSet),2*1024));
            //IDout = new BufferedWriter(new FileWriter(trainId));
            weseout = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(trainWese),2*1024));
            //weseout = new BufferedWriter(new FileWriter(trainWese));
        }
        catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


        try {
            fileout.writeInt(numFeatures);
            weseout.writeInt(1);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        //Log.v("Info", "Features Number Stored: "+nFeatures);
    }

    public Collection<Double> getDescriptor(BufferedImage img){

    	FaceImage fi = new FaceImage();
    	int type = img.getType() == 0? BufferedImage.TYPE_INT_ARGB : img.getType();
    	BufferedImage resizeImageJpg = fi.resizeImage(img, type);
    	
    	/*try {
			ImageIO.write(resizeImageJpg, "jpg", new File("C:/Users/Sadam Hussain/Desktop/AndroidEye/Resized/1.jpg"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/ 
        //Bitmap resImg = FaceImage.resizeBitmap(img, (double) WIDTH / img.getWidth());
        mlbp = new MeraLbp();
        Collection<Double> dag = mlbp.lbpa(resizeImageJpg);
        return dag;
    }
}
