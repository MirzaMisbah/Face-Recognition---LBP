/*import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Locale;

*//**
 * Created by Sadam Hussain on 11/9/2015.
 *//*
public class OneImage {

    public static final String CLASSIFIER_FILE = new File(Database.BASE_DIR, "samples.dat").getAbsolutePath();
    public static final String ID_FILE = new File(Database.BASE_DIR,"id.dat").getAbsolutePath();

    Bitmap bmp;
    NearestNeighbor nn;

    int nFeatures;

    File trainSet;
    File trainId;

    LinkedList<Double> topDist;
    LinkedList<String> topLabel;

    FileInputStream fis = null;
    BufferedInputStream bis = null;
    FileReader fr = null;

    DataInputStream filein;

    BufferedReader IDin;
    LinkedList<Double> cur;
    private int consulteds = 0;

    String curId;

    public void initialize() {
        Locale.setDefault(Locale.US);//to read the double from text file
        cur = new LinkedList<Double>();

        trainSet = new File(CLASSIFIER_FILE);
        trainId = new File(ID_FILE);

        topDist = new LinkedList<Double>();
        topLabel = new LinkedList<String>();

    }

    public void testing(){

        String fname = new File(Environment.getExternalStorageDirectory() + File.separator+"saved_images"+File.separator+"Image-6648.jpg").toString();
        bmp = BitmapFactory.decodeFile(fname);
        Collection<String> labels = topClassify(bmp,1);
        for (String label : labels) {

            String name = Database.personName(label);
            Log.d("Recognize","Yeh banda hai"+name);
        }




    }

    public Collection<String> topClassify(Bitmap img, int topsize){
        //Log.v("NN", "Classifying ...");
        //image = FaceImage.resizeBitmap(image, 0.5, 0.5);//down resolution to improve the face detection time
        //List<Rect> rects = detector.findFaces(image);
        //Log.v("NN", String.format("%d faces detecteds.", rects.size()));

        Collection<String> labels = null;
        //Log.v("NN", "Descriptor");
        nn = new NearestNeighbor();
        Collection<Double> desc = nn.getDescriptor(img);
        if(desc!=null){
            //Log.v("NN", "Searching closest ...");
            labels = topClosest(desc, topsize);
            //Log.v("NN", String.format("%d Closest founds ...", labels.size()));
        }
        else{
            //Log.v("NN", String.format("labels = %p", labels));
            return new LinkedList<String>();//empty list
        }
        //Log.v("NN", "");
        return labels;
    }

    private Collection<String> topClosest(Collection<Double> c, int topsize){
        String minId = null;
        double minDist = Double.MAX_VALUE;
        //Log.d("Haan","beta "+minDist);

        //Log.v("NN", "Comparing to database");

        topDist.clear();
        topLabel.clear();

        for (int i = 0; i < topsize; i++) {
            topDist.add(Double.MAX_VALUE);
            topLabel.add(null);
        }

        int i=0;
        getNumFeatures();

        while(getSample()){

            //Log.v("NN", "Comparing "+i);
            i++;
            //double dist = chiSquareDistance(c, cur);
            double dist = distance(c, cur);
            //Log.d("Threshold","Value "+dist);
            //Log.v("NN", String.format("Comparing with %s - dist = %f", curId, dist));

            Iterator<String> itLabel = topLabel.iterator();
            Iterator<Double> itDist = topDist.iterator();

            for (int j = 0; j < topsize; j++) {
                String s = itLabel.next();
                double d = itDist.next();
                //Log.d("Yeh","Kia hai "+d);

                if (dist<d) {
                    topDist.add(j, dist);
                    topLabel.add(j, new String(curId));

                    topDist.removeLast();
                    topLabel.removeLast();
                    break;
                }
            }
        }
        consulteds = i;
        return topLabel;
    }


    private void getNumFeatures(){

        try {
            //Log.v("NN", "File stream closing ...");
            if(filein!=null){
                filein.close();
                IDin.close();
                filein = null;
                IDin = null;
            }
            //Log.v("NN", String.format("File stream opening ...%s %s", trainSet.getName(), trainId.getName()));

            if(fis!=null){
                fis.close();
                fis=null;
            }
            if(bis!=null){
                bis.close();
                bis=null;
            }
            if(fr!=null){
                fr.close();
                fr=null;
            }

            System.gc();

            fis = new FileInputStream(trainSet);
            bis = new BufferedInputStream(fis,2*1024);
            filein = new DataInputStream(bis);//buffer-100k

            fr = new FileReader(trainId);
            IDin = new BufferedReader(fr, 2*1024);
            System.out.println("NN File stream opened");

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        int x = 0;
        try {
            x = filein.readInt();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        nFeatures = x;
        //Log.v("Info", "Features Number Loaded: "+nFeatures);
    }

    private boolean getSample(){

        cur.clear();
        String s;

        try{
            s = IDin.readLine();
            if (s==null) {
                return false;
            }
            curId = s;
            for (int i = 0; i < nFeatures; i++) {
                double d = (double)filein.readFloat();
                cur.addLast(d);
            }
        }
        catch(Exception e){}

        return true;
    }


    //chi-square distance between samples
    private double chiSquareDistance(Collection<Double> i1, Collection<Double> i2){

        double dist = 0.0;
        double diff;
        double v1, v2;
        double sum;
        assert(i1.size()==i2.size()):"Nao tem o mesmo numero de caracteristicas";

        Iterator<Double> it1 = i1.iterator();
        Iterator<Double> it2 = i2.iterator();

        //Log.v("Info", String.format("Features Number - distance function: %d %d", i1.size(), i2.size()));

        int nFeatures = i1.size();
        for (int i = 0; i < nFeatures; i++)
        {
            v1 = it1.next();
            v2 = it2.next();

            diff = v1 - v2;
            sum = v1 + v2;

            //Log.v("Chi Square", String.format("%f, %f", v1, v2));

            if(sum>0.0)
                dist += (diff*diff)/sum;
        }//while

        return 0.5*dist;
    }

    public double distance(Collection<Double> c1, Collection<Double> c2) {
        // TODO Auto-generated method stub
        return chiSquareDistance(c1, c2);
    }
}
*/